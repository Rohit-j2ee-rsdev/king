package com.kabaddi.pro.service;

import java.util.List;

import com.kabaddi.pro.model.Team;

public interface TeamService {

	List<Team> addTeam(List<Team> team);

	List<Team> findALL();
}
