package com.kabaddi.pro.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kabaddi.pro.model.Match;
import com.kabaddi.pro.model.Team;
import com.kabaddi.pro.service.TeamService;
import com.kabaddi.pro.util.MatchSchedulerUtil;


@RestController
@RequestMapping("/")
public class ProKabaddiController {
	
	
	@Autowired
	private TeamService teamService;
	
	@Autowired
	private MatchSchedulerUtil matchSchedulerUtil;
	
	@PostMapping(value = "/addTeam")
	public String addTeam(@RequestBody List<Team> team) {
		if (team!=null && !team.isEmpty()) {
			teamService.addTeam(team);
		}
		return "ALL team added successfully";
	}
	
	@GetMapping(value = "/getAllTeam")
	public List<Team> getAllTeam(){
		return teamService.findALL();
	}
	
	
	@GetMapping(value = "/getAllMatches")
	public List<Match> getAllMatches(){
		List<Match> matchList=new ArrayList<>();
		List<Team> teams=teamService.findALL();
		if (teams!=null && !teams.isEmpty()) {
			matchList=matchSchedulerUtil.generate(teams, LocalDateTime.now());
		}
		return matchList;
	}
	

	
	
	
}
