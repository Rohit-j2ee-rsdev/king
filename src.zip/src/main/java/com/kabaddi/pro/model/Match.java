package com.kabaddi.pro.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.annotation.Generated;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Match implements Serializable {

	private static final long serialVersionUID = 862378770190262427L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="match_id")
	private int matchId;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "match_id")
	private List<Team> teams;

	
	
	private String location;
	private LocalDate date;
	
	public Match(List<Team> teams) {
		super();
		this.teams = teams;
	}

	

}
