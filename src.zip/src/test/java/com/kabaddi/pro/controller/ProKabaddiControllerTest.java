package com.kabaddi.pro.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.kabaddi.pro.controller.ProKabaddiController;
import com.kabaddi.pro.model.Team;
import com.kabaddi.pro.service.TeamService;
import com.kabaddi.pro.util.MatchSchedulerUtil;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class ProKabaddiControllerTest {
	
	@InjectMocks
	private ProKabaddiController proKabaddiController;

	@Mock
	private TeamService teamService;
	
	@Mock
	private MatchSchedulerUtil matchSchedulerUtil;
	
	@Test
	public void addTeamTest(){
		 List<Team> list = new ArrayList<Team>();
		 list.add(new Team(1,"Pune-worrior","pune"));
		 list.add(new Team(2,"Mumbai-worrior","mumbai"));
		 list.add(new Team(1,"Nagpur-worrior","Nagpur"));
		 
		 when(teamService.addTeam(list)).thenReturn(list);
		 
		 //test case
		 teamService.addTeam(list);
		 
		 assertEquals(3, list.size());
		
	}
}
