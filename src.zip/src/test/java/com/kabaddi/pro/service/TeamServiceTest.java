package com.kabaddi.pro.service;

import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Rule;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.MockitoRule;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.kabaddi.pro.dao.TeamRepository;
import com.kabaddi.pro.model.Team;

@RunWith(MockitoJUnitRunner.class)
 @SpringBootTest
public class TeamServiceTest {


	@Mock
	private TeamRepository teamRepository;
	
	@InjectMocks
	private TeamServiceImpl teamService;

	@Rule 
	public MockitoRule mockitoRule = MockitoJUnit.rule();

	@Before
	public void setUp() {
	//	MockitoAnnotations.initMocks(this);
	}

	@Test
	public void addTeamTest_usingMock() throws Exception {
		
		Team team1=new Team(1, "Pune-worriers",  "Pune");
		Team team2 =new Team(2,"Mumbai-worriers","Mumbai");
		Team team3 =new Team(3,"Nagpur-worriers","Nagpur");
		Team team4 =new Team(4,"Nashik-worriers","Nashik");
		
		List<Team> teams=new ArrayList<>();
		
		teams.add(team1);
		teams.add(team2);
		teams.add(team3);
		teams.add(team4);
		
		when(teamRepository.saveAll(teams)).thenReturn(teams);
		
		List<Team> result = teamService.addTeam(teams);
		
		assertThat(result,hasItems(new Team(1, "Pune-worriers",  "Pune")));
		
		assertThat(result.size(),is(4));
	//	assertEquals("Todo Sample 8", result.getText());
	//	assertEquals(true, result.isCompleted());
	}
}
