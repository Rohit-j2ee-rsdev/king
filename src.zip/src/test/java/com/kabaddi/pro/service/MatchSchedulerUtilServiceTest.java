/*
 * package com.kabaddi.pro.service;
 * 
 * import org.junit.Before; import org.junit.Rule; import
 * org.junit.jupiter.api.Test; import org.junit.runner.RunWith; import
 * org.mockito.InjectMocks; import org.mockito.Mock; import
 * org.mockito.junit.MockitoJUnit; import org.mockito.junit.MockitoJUnitRunner;
 * import org.mockito.junit.MockitoRule; import
 * org.springframework.boot.test.context.SpringBootTest;
 * 
 * import com.kabaddi.pro.dao.MatchRepository; import
 * com.kabaddi.pro.util.MatchSchedulerUtil;
 * 
 * @RunWith(MockitoJUnitRunner.class)
 * 
 * @SpringBootTest public class MatchSchedulerUtilServiceTest {
 * 
 * @InjectMocks private MatchSchedulerUtil matchService;
 * 
 * @Mock private MatchRepository matchRepository;
 * 
 * @Rule public MockitoRule mockitoRule = MockitoJUnit.rule();
 * 
 * @Before
 * 
 * 
 * @Test public void initializeMatches(){
 * 
 * } }
 */